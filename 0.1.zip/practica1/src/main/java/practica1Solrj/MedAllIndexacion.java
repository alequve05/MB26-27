package practica1Solrj;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.common.SolrInputDocument;
import org.springframework.stereotype.Component;

@Component
public class MedAllIndexacion {

	public void indexar(String rutaArchivo) throws SolrServerException, IOException {
		// Creamos el cliente
		final SolrClient client = new HttpSolrClient.Builder("http://localhost:8983/solr").build();
		
		BufferedReader br = new BufferedReader(new FileReader(rutaArchivo));
		String linea;
		String id = null;
		String texto = "";
		
		while((linea = br.readLine()) != null)
		{
			linea = linea.trim();
			
			if (linea.startsWith(".I"))
			{
				// Si se había leído un documento anterior, se añade a Solr
				if (id != null)
				{
					SolrInputDocument doc = new SolrInputDocument();
					doc.addField("id", id);
					doc.addField("text", texto.trim());
					client.add("corpus", doc);
				}
				// Guardamos el nuevo ID del documento (el .I) y vacíamos el texto
				id = linea.substring(2).trim();
				texto = "";
			} else if (linea.equals(".W"))
			{
				// Simplemente se ignora 
			} else
			{
				texto += linea + " ";
			}
		}
		
		// Añadir el último documento del fichero
		if (id != null)
		{
			SolrInputDocument doc = new SolrInputDocument();
			doc.addField("id", id);
			doc.addField("text", texto);
			client.add("corpus", doc);
		}
		
		br.close();
		
		// Indexed documents must be committed
		client.commit("corpus");
		System.out.println("Documentos indexados en corpus");
	}
	
	// Este main es solo para probar
	public static void main(String[] args) throws SolrServerException, IOException {
		new MedAllIndexacion().indexar("src/main/resources/MED.ALL");
	}

}
