package practica1Solrj;

import java.io.IOException;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrQuery.ORDER;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocumentList;
import org.springframework.stereotype.Component;

@Component
public class MedAllBusqueda {
	
	public void buscar(String consulta) throws IOException, SolrServerException {
		// Abrimos el cliente
		HttpSolrClient solr = new HttpSolrClient.Builder("http://localhost:8983/solr/corpus").build();
		
		SolrQuery query = new SolrQuery();
		query.setQuery(consulta); // Ej: *:*
		query.setFields("id", "text");
		query.setRows(50);
		query.setSort("id", ORDER.asc);
		
		QueryResponse rsp = solr.query(query);
		SolrDocumentList docs = rsp.getResults();
		
		System.out.println("Documentos encontrados: " + docs.getNumFound());
		for (int i = 0; i < docs.size(); i++)
		{
			System.out.println(docs.get(i));
		}
	}
	
	// Esto es solo para probar
	public static void main(String[] args) throws IOException, SolrServerException {
		new MedAllBusqueda().buscar("*:*");
	}
}
