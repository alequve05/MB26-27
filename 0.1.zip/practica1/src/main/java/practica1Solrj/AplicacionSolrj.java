package practica1Solrj;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicacionSolrj implements CommandLineRunner {

    @Autowired
    private MedAllIndexacion indexador;
    
    @Autowired
    private MedAllBusqueda buscador;
    
    public static void main(String[] args) {
    	SpringApplication.run(AplicacionSolrj.class, args);
    }

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int opcion = -1;
		
		while(opcion != 0)
		{
			System.out.println("-- MENÚ --");
			System.out.println("1. Indexar MED.ALL en 'corpus'");
			System.out.println("2. Buscar");
			System.out.println("0. Salir");
			System.out.print("Elige una opción: ");
			
			opcion = Integer.parseInt(sc.nextLine());
			
			if (opcion == 1)
				indexador.indexar("src/main/resources/MED.ALL");
			else if (opcion == 2)
			{
				System.out.print("Introduce la consulta: ");
				String consulta = sc.nextLine();
				buscador.buscar(consulta);
			}
		}
		
		sc.close();
	}
}